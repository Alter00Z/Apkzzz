# Pixel Lines

Android app that draws 1-pixel vertical lines over every other app.

- Colors: OLED black (#000000), white, red, green, blue, yellow, cyan, magenta, orange, gray, or any #RRGGBB
- One line or many (up to 30), with adjustable spacing
- Move the lines left/right with a slider or 1 px / 10 px nudge buttons (hold to repeat)
- Touches pass through, so you can keep using your phone

## Build the APK

### Option A: Android Studio (on a computer)
1. Install Android Studio and open this folder.
2. Wait for Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

### Option B: GitHub (no install needed)
1. Create a free GitHub account and a new repository.
2. Upload all files from this folder to the repository (keep the `.github` folder).
3. Open the Actions tab > "Build APK" > Run workflow.
4. When it finishes, download `PixelLines-debug-apk` from the run page and unzip it.

## Install on your phone
1. Copy `app-debug.apk` to the phone and open it (allow "Install unknown apps" for your file manager or browser).
2. Open Pixel Lines, tap Start overlay, and enable "Display over other apps" when asked.
3. Go back and tap Start overlay again.
