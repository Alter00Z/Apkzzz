package com.example.pixellines

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var sp: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var screenW = 1080

    private lateinit var toggleBtn: Button
    private lateinit var posLabel: TextView
    private lateinit var posSeek: SeekBar
    private lateinit var countLabel: TextView
    private lateinit var gapLabel: TextView
    private lateinit var colorLabel: TextView
    private val swatches = mutableListOf<TextView>()

    private val colors: List<Pair<String, Int>> = listOf(
        "OLED Black" to 0xFF000000.toInt(),
        "White" to 0xFFFFFFFF.toInt(),
        "Red" to 0xFFFF0000.toInt(),
        "Green" to 0xFF00FF00.toInt(),
        "Blue" to 0xFF0000FF.toInt(),
        "Yellow" to 0xFFFFFF00.toInt(),
        "Cyan" to 0xFF00FFFF.toInt(),
        "Magenta" to 0xFFFF00FF.toInt(),
        "Orange" to 0xFFFF8800.toInt(),
        "Gray" to 0xFF808080.toInt()
    )

    // Position of the first line, in pixels from the left edge. Writing it saves and refreshes the UI.
    private var pos: Int
        get() = sp.getInt(Prefs.POS, Prefs.defaultPos(this))
        set(v) {
            sp.edit().putInt(Prefs.POS, v.coerceIn(0, screenW - 1)).apply()
            showPos()
        }

    private fun count(): Int = sp.getInt(Prefs.COUNT, Prefs.DEFAULT_COUNT)
    private fun gap(): Int = sp.getInt(Prefs.GAP, Prefs.DEFAULT_GAP)
    private fun color(): Int = sp.getInt(Prefs.COLOR, Prefs.DEFAULT_COLOR)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = Prefs.sp(this)
        screenW = Prefs.screenWidth(this)
        setContentView(buildUi())

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        updateToggle(OverlayService.running)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }

        col.addView(TextView(this).apply {
            text = "Pixel Lines"
            textSize = 28f
        })

        toggleBtn = Button(this).apply { setOnClickListener { toggle() } }
        col.addView(toggleBtn, matchWrap())

        // ---- Position
        col.addView(heading("Position"))
        posLabel = TextView(this)
        col.addView(posLabel)
        posSeek = seek(screenW - 1, pos.coerceIn(0, screenW - 1)) { pos = it }
        col.addView(posSeek, matchWrap())

        val nudges = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((label, delta) in listOf("◀ 10" to -10, "◀ 1" to -1, "1 ▶" to 1, "10 ▶" to 10)) {
            nudges.addView(
                nudgeButton(label, delta),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        col.addView(nudges, matchWrap())
        showPos()

        // ---- Multiple lines
        col.addView(heading("Multiple lines"))
        countLabel = TextView(this)
        col.addView(countLabel)
        col.addView(
            seek(Prefs.MAX_COUNT - 1, count() - 1) {
                sp.edit().putInt(Prefs.COUNT, it + 1).apply()
                showMulti()
            },
            matchWrap()
        )
        gapLabel = TextView(this)
        col.addView(gapLabel)
        col.addView(
            seek(Prefs.MAX_GAP - Prefs.MIN_GAP, gap() - Prefs.MIN_GAP) {
                sp.edit().putInt(Prefs.GAP, it + Prefs.MIN_GAP).apply()
                showMulti()
            },
            matchWrap()
        )
        showMulti()

        // ---- Color
        col.addView(heading("Color"))
        val grid = GridLayout(this).apply { columnCount = 5 }
        for ((name, c) in colors) {
            val sw = TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 10f
                setTextColor(Color.WHITE)
                text = if (name == "OLED Black") "OLED" else ""
                setOnClickListener { setColor(c) }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = dp(52)
                height = dp(52)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            swatches.add(sw)
            grid.addView(sw, lp)
        }
        col.addView(grid)

        colorLabel = TextView(this)
        col.addView(colorLabel)

        val hexRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val hexInput = EditText(this).apply {
            hint = "#RRGGBB"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        hexRow.addView(hexInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        hexRow.addView(Button(this).apply {
            text = "Apply"
            setOnClickListener {
                val raw = hexInput.text.toString().trim()
                val t = if (raw.startsWith("#")) raw else "#$raw"
                try {
                    setColor(Color.parseColor(t) or (0xFF shl 24))
                } catch (e: IllegalArgumentException) {
                    Toast.makeText(this@MainActivity, "Use the format #RRGGBB", Toast.LENGTH_SHORT).show()
                }
            }
        })
        col.addView(hexRow, matchWrap())
        styleSwatches()

        col.addView(TextView(this).apply {
            text = "Lines are 1 pixel wide, run the full height of the screen and let touches " +
                "pass through, so you can keep using your phone. Stop them here or from the notification."
            setPadding(0, dp(24), 0, 0)
        })

        return ScrollView(this).apply {
            isFillViewport = true
            addView(col)
        }
    }

    private fun toggle() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            updateToggle(false)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(
                this,
                "Turn on \"Display over other apps\", go back, then tap Start",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        updateToggle(true)
    }

    private fun updateToggle(on: Boolean) {
        toggleBtn.text = if (on) "Stop overlay" else "Start overlay"
    }

    private fun showPos() {
        posLabel.text = "From left edge: $pos px  (screen is $screenW px wide)"
        posSeek.progress = pos.coerceIn(0, screenW - 1)
    }

    private fun showMulti() {
        countLabel.text = "Number of lines: ${count()}"
        gapLabel.text = "Spacing between lines: ${gap()} px"
    }

    private fun setColor(c: Int) {
        sp.edit().putInt(Prefs.COLOR, c).apply()
        styleSwatches()
    }

    private fun styleSwatches() {
        val cur = color()
        colors.forEachIndexed { i, entry ->
            swatches[i].background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8).toFloat()
                setColor(entry.second)
                if (entry.second == cur) {
                    setStroke(dp(4), 0xFF00BCD4.toInt())
                } else {
                    setStroke(dp(1), 0xFF888888.toInt())
                }
            }
        }
        val name = colors.firstOrNull { it.second == cur }?.first ?: "Custom"
        colorLabel.text = "Color: $name (#%06X)".format(cur and 0xFFFFFF)
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun matchWrap() =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun heading(t: String) = TextView(this).apply {
        text = t
        textSize = 18f
        setTextColor(0xFF00BCD4.toInt())
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun seek(maxV: Int, startV: Int, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            max = maxV
            progress = startV
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) onChange(p)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

    /** Button that nudges the position by [delta] px; keeps repeating while held down. */
    private fun nudgeButton(label: String, delta: Int): Button = Button(this).apply {
        text = label
        // Explicit this@MainActivity: inside a View, plain `handler` would mean View.getHandler().
        val h = this@MainActivity.handler
        val repeat = object : Runnable {
            override fun run() {
                this@MainActivity.pos += delta
                h.postDelayed(this, 50)
            }
        }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    this@MainActivity.pos += delta
                    h.postDelayed(repeat, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    h.removeCallbacks(repeat)
                }
            }
            true
        }
    }
}
