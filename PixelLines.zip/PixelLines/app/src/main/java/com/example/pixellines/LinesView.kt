package com.example.pixellines

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/**
 * Full-screen transparent view that draws exactly-1-pixel-wide vertical lines.
 * Anti-aliasing is off and coordinates are whole pixels, so each line is crisp.
 */
class LinesView(context: Context) : View(context) {

    private val paint = Paint().apply {
        isAntiAlias = false
        style = Paint.Style.FILL
    }

    private var pos = 0
    private var count = 1
    private var gap = 20

    fun setConfig(pos: Int, count: Int, gap: Int, color: Int) {
        this.pos = pos
        this.count = count
        this.gap = gap
        paint.color = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val h = height.toFloat()
        for (i in 0 until count) {
            val x = pos + i * gap
            if (x >= width) break
            if (x < 0) continue
            canvas.drawRect(x.toFloat(), 0f, x + 1f, h, paint)
        }
    }
}
