package com.example.pixellines

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

/** Shared settings, stored in SharedPreferences and read by both the UI and the overlay service. */
object Prefs {
    private const val FILE = "pixellines"

    const val POS = "pos"       // x position (px from the left edge) of the first line
    const val COUNT = "count"   // number of lines
    const val GAP = "gap"       // distance in px between the start of one line and the next
    const val COLOR = "color"   // ARGB color

    const val MAX_COUNT = 30
    const val MIN_GAP = 2
    const val MAX_GAP = 300
    const val DEFAULT_COUNT = 1
    const val DEFAULT_GAP = 20
    val DEFAULT_COLOR: Int = Color.RED

    fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun screenWidth(ctx: Context): Int {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            wm.maximumWindowMetrics.bounds.width()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels
        }
    }

    fun defaultPos(ctx: Context): Int = screenWidth(ctx) / 2
}
